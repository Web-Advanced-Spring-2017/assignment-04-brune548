# Assignment 04

This application allows users to track where their friends are. I originally wanted this to be an AR app, but for now, I have it as a way of showing where to find their ping. Once you click on the location button, it directs you to another tab, which only works if you have another browser open. Then you will be able to see your ping. The sockets don't work right now, but I am still trying to figure how to fix that. 


## References
- [API](https://developers.google.com/maps/documentation/geolocation/intro)

- [Sockets](https://socket.io/)


